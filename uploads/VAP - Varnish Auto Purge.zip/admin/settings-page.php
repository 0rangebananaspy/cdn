<?php
// Admin settings page
add_action('admin_menu', function () {
    add_options_page('Varnish Auto Purge Settings', 'Varnish Auto Purge', 'manage_options', 'vap-settings', 'vap_render_settings_page');
});

add_action('admin_init', function () {
    register_setting('vap_settings_group', 'vap_varnish_host');
    register_setting('vap_settings_group', 'vap_varnish_port');
    register_setting('vap_settings_group', 'vap_host_header');
    register_setting('vap_settings_group', 'vap_purge_homepage');
    register_setting('vap_settings_group', 'vap_purge_post_url');
    register_setting('vap_settings_group', 'vap_purge_taxonomies');
});

function vap_render_settings_page() {
    ?>
    <div class="wrap">
        <h1>Varnish Auto Purge Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields('vap_settings_group'); ?>
            <?php do_settings_sections('vap_settings_group'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Varnish Host</th>
                    <td><input type="text" name="vap_varnish_host" value="<?php echo esc_attr(get_option('vap_varnish_host', '127.0.0.1')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row">Varnish Port</th>
                    <td><input type="number" name="vap_varnish_port" value="<?php echo esc_attr(get_option('vap_varnish_port', 6081)); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row">Host Header</th>
                    <td><input type="text" name="vap_host_header" value="<?php echo esc_attr(get_option('vap_host_header', $_SERVER['HTTP_HOST'])); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row">Purge Homepage</th>
                    <td><input type="checkbox" name="vap_purge_homepage" value="1" <?php checked(1, get_option('vap_purge_homepage', 1)); ?> /></td>
                </tr>
                <tr>
                    <th scope="row">Purge Post URL</th>
                    <td><input type="checkbox" name="vap_purge_post_url" value="1" <?php checked(1, get_option('vap_purge_post_url', 1)); ?> /></td>
                </tr>
                <tr>
                    <th scope="row">Purge Taxonomies</th>
                    <td><input type="checkbox" name="vap_purge_taxonomies" value="1" <?php checked(1, get_option('vap_purge_taxonomies', 1)); ?> /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
