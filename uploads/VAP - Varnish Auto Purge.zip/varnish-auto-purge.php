<?php
/*
Plugin Name: VAP - Varnish Auto Purge
Description: Automatically purges Varnish Cache on publish, update, trash, or delete for all public post types. Includes homepage, post URL, and category/tag archives.
Version: 1.2
Author: Agung Hendro | tik.unej.ac.id
*/

defined('ABSPATH') or die('No script kiddies please!');

// === Load Settings ===
require_once plugin_dir_path(__FILE__) . 'admin/settings-page.php';

// === Load Config from DB or use defaults ===
$varnish_host     = get_option('vap_varnish_host', '127.0.0.1');
$varnish_port     = (int)get_option('vap_varnish_port', 6081);
$host_header      = get_option('vap_host_header', $_SERVER['HTTP_HOST']);
$purge_homepage   = get_option('vap_purge_homepage', true);
$purge_post_url   = get_option('vap_purge_post_url', true);
$purge_taxonomies = get_option('vap_purge_taxonomies', true);

// === Purge Function ===
function vap_purge_url($url_path) {
    global $varnish_host, $varnish_port, $host_header;

    $fp = fsockopen($varnish_host, $varnish_port, $errno, $errstr, 10);
    if ($fp) {
        $out = "PURGE $url_path HTTP/1.1\r\n";
        $out .= "Host: $host_header\r\n";
        $out .= "Connection: Close\r\n\r\n";
        fwrite($fp, $out);
        fclose($fp);
    }
}

// === Hook Actions ===
function vap_handle_purge($post_ID) {
    global $purge_homepage, $purge_post_url, $purge_taxonomies;

    $post = get_post($post_ID);
    if (!$post || $post->post_status !== 'publish') return;

    if ($purge_homepage) {
        vap_purge_url('/');
    }

    if ($purge_post_url) {
        $post_url = parse_url(get_permalink($post_ID), PHP_URL_PATH);
        vap_purge_url($post_url);
    }

    if ($purge_taxonomies) {
        $taxonomies = get_object_taxonomies($post->post_type);
        foreach ($taxonomies as $taxonomy) {
            $terms = get_the_terms($post_ID, $taxonomy);
            if (!empty($terms) && !is_wp_error($terms)) {
                foreach ($terms as $term) {
                    $term_link = get_term_link($term);
                    if (!is_wp_error($term_link)) {
                        $term_path = parse_url($term_link, PHP_URL_PATH);
                        vap_purge_url($term_path);
                    }
                }
            }
        }
    }
}
add_action('publish_post', 'vap_handle_purge');
add_action('publish_page', 'vap_handle_purge');
add_action('save_post', 'vap_handle_purge');
add_action('deleted_post', 'vap_handle_purge');
add_action('trashed_post', 'vap_handle_purge');
