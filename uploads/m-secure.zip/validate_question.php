<?php
// Security question validation
$correctAnswer = "8";  // Define the correct answer here
$userAnswer = $_POST['security_answer'];

// hCaptcha validation
$secretKey = "ES_0823cb3021ac4212944f18be417c4a8b";  // Replace with your hCaptcha secret key
$responseKey = $_POST['h-captcha-response'];
$userIP = $_SERVER['REMOTE_ADDR'];

$api_url = "https://hcaptcha.com/siteverify?secret=$secretKey&response=$responseKey&remoteip=$userIP";
$response = file_get_contents($api_url);
$responseData = json_decode($response);

// Check both the security question and hCaptcha response
if ($userAnswer === $correctAnswer && $responseData->success) {
    // Both checks passed, proceed with login or further processing
    header("Location: https://jurnal.unej.ac.id/index.php/index/login");  // Replace with the appropriate page
} else {
    // Either the security question or hCaptcha failed
    echo "Please complete the security checks correctly.";
}
?>
